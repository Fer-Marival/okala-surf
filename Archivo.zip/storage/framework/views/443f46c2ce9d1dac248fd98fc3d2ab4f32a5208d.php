<?php $__env->startSection('content'); ?>
	<div class="home">
		<div class="slider-pro" id="home-slider">
			<div class="sp-slides">
				<div class="sp-slide">
					<img class="sp-image" src="<?php echo e(asset('img/home.jpeg')); ?>" />
				</div>
			</div>
			<div class="sp-slides">
				<div class="sp-slide">
					<img class="sp-image" src="<?php echo e(asset('img/home2.jpeg')); ?>" />
				</div>
			</div>
			<div class="sp-slides">
				<div class="sp-slide">
					<img class="sp-image" src="<?php echo e(asset('img/girls.jpg')); ?>" />
				</div>
			</div>
		</div>
	</div>
	<div class="wave">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1170 193">
			<path fill="#09cbea" d="M1175 131.2c0 0-81-89.4-224.3-103.4S713 72 665 97c-86 46-148 63-271 7C221.7 25.5 56 104.5-4 197.4 -4 58.7-3.3 0.3-3.3 0.3L1175 0V131.2z"></path>
		</svg>
	</div>
	<section class="services">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="service">	
						<img src="<?php echo asset('img/services/3.svg'); ?>" alt="">
						<div class="title">
							<?php echo app('translator')->getFromJson('global.table'); ?>
						</div>
						<div class="description">
							<?php echo app('translator')->getFromJson('global.table-des'); ?>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="service">
						<img src="<?php echo asset('img/services/1.svg'); ?>" alt="">
						<div class="title">
							<?php echo app('translator')->getFromJson('global.transportation'); ?>
						</div>
						<div class="description">
							<?php echo app('translator')->getFromJson('global.trans-des'); ?>
						</div>
					</div>					
				</div>
				<div class="col-md-4">
					<div class="service">
						<img src="<?php echo asset('img/services/2.svg'); ?>" alt="">
						<div class="title">
							<?php echo app('translator')->getFromJson('global.swimmer'); ?>
						</div>	
						<div class="description">
							<?php echo app('translator')->getFromJson('global.swim-des'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<div id="wave">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1170 193">
			<path fill="#09cbea" d="M1175 131.2c0 0-81-89.4-224.3-103.4S713 72 665 97c-86 46-148 63-271 7C221.7 25.5 56 104.5-4 197.4 -4 58.7-3.3 0.3-3.3 0.3L1175 0V131.2z"></path>
		</svg>
	</div>	
	<div id="description">
		<div class="container">
			<div class="row align-items-center" id="scene">
				<div class="col-md-6" data-depth="0.2">
					<picture><img src="<?php echo e(asset('img/home2.jpg')); ?>"  alt="" class="img-fluid"></picture>
				</div>
				<div class="col-md-6">
					<div class="title">
						<h1>Okala</h1>
						<h2><?php echo app('translator')->getFromJson('global.subname'); ?></h2>
					</div>
					<div class="content">
							<?php echo app('translator')->getFromJson('global.description'); ?><br /><br />
						<a href="/booking" class="btn-hover color-9"><?php echo app('translator')->getFromJson('global.book'); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="clear"></div>
	<section class="instagram">
		<div class="container-fluid">
			<h3><?php echo app('translator')->getFromJson('global.moments'); ?></h3>
		<div class="row">
			<div class="card-columns">
			  <div class="card">
			    	<img src="<?php echo asset('img/girls.jpg'); ?>" class="card-img-top" alt="...">
			  </div>
			  <div class="card">
			    <img src="<?php echo asset('img/girls2.jpg'); ?>" class="card-img-top" alt="...">
			  </div>
			  <div class="card">
			   	<img src="<?php echo asset('img/avent1.jpg'); ?>" class="card-img-top" alt="...">
			   </div>
			  <div class="card">
			    <img src="<?php echo asset('img/lesson.jpg'); ?>" class="card-img-top" alt="...">
			  </div>
			  <div class="card">
			   	<img src="<?php echo asset('img/events/1.jpeg'); ?>" class="card-img-top" alt="...">
			  </div>
			  <div class="card">
			  	<img src="<?php echo asset('img/booking3.jpeg'); ?>" class="card-img-top" alt="...">
			  </div>
			</div>
		</div>
		</div>
	</section>
	<div class="clear"></div>
	<div id="social">
			<h3><?php echo app('translator')->getFromJson('global.follow'); ?><span>&#x02992;</span></h3>
			<div id="instafeed" class='grid row'>
			  	<div class="grid-sizer"></div>
			</div>
		</div>
	<section class="coments">
		<div class="container">
			<div class="row">
				<div class="col"><h3 class="title"><?php echo app('translator')->getFromJson('global.review'); ?></h3></div>
				<div class="col-md-12">
						<div class="slider-pro" id="my-slider">
							<div class="sp-slides">
								<div class="sp-slide">
									<section>
										<img src="<?php echo asset('img/clientes/1.jpg'); ?>" alt="" class="shadow">
										<span>&#x2605;</span><span>&#x2605;</span><span>&#x2605;</span><span>&#x2605;</span><span>&#x2605;</span>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam ratione illo quos neque dolore velit, est adipisci dolor </p>
										<em>juana- USA</em>
									</section>
								</div>
								<div class="sp-slide">
									<section>
									<img src="<?php echo asset('img/clientes/2.jpg'); ?>" alt="" class="shadow">
									<span>&#x2605;</span><span>&#x2605;</span><span>&#x2605;</span><span>&#x2605;</span><span>&#x2605;</span>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam ratione illo quos neque dolore velit, est adipisci dolor </p>
									<em>juana- USA</em>
								</section>
								</div>
								<div class="sp-slide">
									<section>
										<img src="<?php echo asset('img/clientes/23.jpg'); ?>" alt="" class="shadow">
										<span>&#x2605;</span><span>&#x2605;</span><span>&#x2605;</span><span>&#x2605;</span><span>&#x2605;</span>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam ratione illo quos neque dolore velit, est adipisci dolor </p>
										<em>juana- USA</em>
									</section>
								</div>
							</div>
						</div>
				</div>
			</div>
		</div>
	</section>
	<div class="clear"></div>
	
	<div class="clear"></div>
	<section class="events">
		<div class="container">
			<h2><?php echo app('translator')->getFromJson('global.events'); ?></h2>
			<div class="row">
				<div class="col">
					<section class="event">
						<img src="<?php echo asset('img/events/1.jpeg'); ?>" class="img-fluid" alt="">
						<em>Limpieza de playas</em>
						<a href="#">Read more…</a>
					</section>
				</div>
				<div class="col">
					<section class="event">
						<img src="<?php echo asset('img/events/2.jpg'); ?>" class="img-fluid" alt="">
						<em>Apoyo a perros sin hogar</em>
						<a href="#">Read more…</a>
					</section>
				</div>
				<div class="col">
					<section class="event">
						<img src="<?php echo asset('img/events/3.jpg'); ?>" class="img-fluid" alt="">
						<em>Limpieza de islas marietas</em>
						<a href="#">Read more…</a>
					</section>
				</div>
			</div>
		</div>
	</section>
	<div class="contact">
		<div class="container">
			<h3><?php echo app('translator')->getFromJson('global.contact'); ?> 🤙</h3>
			
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.principal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
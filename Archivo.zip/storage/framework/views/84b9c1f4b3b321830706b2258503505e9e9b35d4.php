
Hello,
You received a message from : <?php echo e($name); ?>

 
<p>
User Name: <?php echo e($name); ?>

</p>
 
<p>
User Email: <?php echo e($email); ?>

</p>
 
<h2>Nueva resrevacion de:</h2>
<h1><?php echo e($name); ?> <?php echo e($lastname); ?></h1>  
<p><?php echo e($email); ?></p>
<p><?php echo e($cellphone); ?></p>
<p><?php echo e($country); ?></p>
<p><?php echo e($city); ?></p>
<p><?php echo e($state); ?></p>
<p><?php echo e($pk_adress); ?></p>
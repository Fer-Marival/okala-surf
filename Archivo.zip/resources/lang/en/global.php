<?php

return [
    'welcome' => 'Welcome to our application',

    //servics:
    'table' => 'Surf table inlcuded',
    'table-des' => 'Olvídate de cargar con la tabla,  nosotros tenemos el mejor equipo para que tu aprendas a  Surfear bro.',
    'transportation' => 'Transportation',
   	'trans-des' => 'Bro, tu sólo envía tu ubicación y nosotros vamos por ti para que estés relajado y contento para la  clase.',
    'swimmer' =>'Swimmer',
    'swim-des' =>'Hey bro,  no gastes en trajes de baño  de  flores,  la lycra va de nuestra parte para que disfrutes tu clase sin preocupaciones.'
];
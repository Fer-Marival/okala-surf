
Hello,
You received a message from : {{ $name }}
 
<p>
User Name: {{ $name }}
</p>
 
<p>
User Email: {{ $email }}
</p>
 
<h2>Nueva resrevacion de:</h2>
<h1>{{ $name }} {{ $lastname }}</h1>  
<p>{{ $email  }}</p>
<p>{{ $cellphone  }}</p>
<p>{{ $country  }}</p>
<p>{{ $city  }}</p>
<p>{{ $state  }}</p>
<p>{{ $pk_adress  }}</p>
<?php

namespace Coconuts\Mail\Exceptions;

class PostmarkException extends \Exception
{
}
